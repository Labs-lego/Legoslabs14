const json = (statusCode, body) => new Response(JSON.stringify(body), { status: statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });

// Catalogue : [préfixe du nom envoyé par le panier, prix en €]
const KEYRING = 'Porte-clés CLV';
const CATALOGUE = [
  ['T-shirt N°', 39],
  ['C/V Luxury Hoodie', 99.99],
  ['Casquette Polaire CLV', 59],
  [KEYRING, 10]
];

// Zones de livraison (montants en centimes). Le client choisit son pays sur le site.
const EUROPE = ['FR','BE','LU','NL','DE','ES','IT','PT','AT','IE','CH','GB','DK','SE','FI','PL','CZ','GR'];
const ASIA = ['HK','MO','TW','JP','KR','SG','MY','TH','VN','ID','PH','IN','KH','LA','BN','MN','KZ','UZ','LK','BD','NP','MV','AE','SA','QA','KW','BH','OM','IL','TR'];
const WORLD = ['US','CA','AU','NZ','MX','BR','AR','CL','CO','ZA','MA','TN','EG','SN','CI'];
const CHINA = ['CN'];

const SHIPPING_EUROPE = [
  { name: 'Point relais / casier automatique', amount: 599, min: 3, max: 5 },
  { name: 'Livraison à domicile', amount: 799, min: 3, max: 5 }
];
const SHIPPING_FREE = [{ name: 'Livraison offerte (porte-clés)', amount: 0, min: 3, max: 5 }];
const SHIPPING_CHINA = [{ name: 'Livraison Chine', amount: 1850, min: 7, max: 15 }];
const SHIPPING_ASIA = [{ name: 'Livraison Asie', amount: 2000, min: 7, max: 15 }];
const SHIPPING_WORLD = [{ name: 'Livraison internationale', amount: 2200, min: 7, max: 15 }];

function shippingFor(country, onlyKeyrings) {
  if (EUROPE.includes(country)) return onlyKeyrings ? SHIPPING_FREE : SHIPPING_EUROPE;
  if (CHINA.includes(country)) return SHIPPING_CHINA;
  if (ASIA.includes(country)) return SHIPPING_ASIA;
  if (WORLD.includes(country)) return SHIPPING_WORLD;
  return null;
}

// Moyens de paiement : carte (Apple/Google Pay inclus) + Alipay + WeChat Pay
const PAYMENT_METHODS = ['card', 'alipay', 'wechat_pay'];

export async function onRequestPost({ request, env }) {
  if (request.method !== 'POST') return json(405, { error: 'Méthode non autorisée' });

  const key = env.STRIPE_SECRET_KEY;
  if (!key) {
    console.error('[create-checkout] STRIPE_SECRET_KEY absente');
    return json(500, { error: 'Configuration Stripe incomplète : clé secrète absente dans Cloudflare Pages.' });
  }

  let items, country;
  try {
    const body = JSON.parse(await request.text() || '{}');
    items = body.items;
    country = String(body.country || '').toUpperCase();
  } catch (err) {
    return json(400, { error: 'Requête invalide : panier illisible.' });
  }
  if (!Array.isArray(items) || !items.length || items.length > 30) {
    return json(400, { error: 'Panier invalide ou vide.' });
  }

  const shippingOptions = shippingFor(country, items.every((it) => String(it.name || '').startsWith(KEYRING)));
  if (!shippingOptions) return json(400, { error: 'Veuillez choisir un pays de livraison dans le panier.' });

  const p = new URLSearchParams();
  let subtotal = 0;
  let i = 0;
  for (const item of items) {
    if (!item || typeof item !== 'object') return json(400, { error: 'Article invalide dans le panier.' });
    const product = CATALOGUE.find(([name]) => String(item.name || '').startsWith(name));
    const qty = Math.floor(Number(item.qty));
    if (!product || !(qty >= 1 && qty <= 20)) {
      console.error('[create-checkout] Article refusé:', String(item.name || 'nom absent').slice(0, 100), 'quantité:', item.qty);
      return json(400, { error: 'Un article du panier n’est pas reconnu. Videz le panier puis réessayez.' });
    }
    p.append(`line_items[${i}][price_data][currency]`, 'eur');
    p.append(`line_items[${i}][price_data][product_data][name]`, String(item.name).slice(0, 120));
    p.append(`line_items[${i}][price_data][unit_amount]`, String(Math.round(product[1] * 100)));
    p.append(`line_items[${i}][quantity]`, String(qty));
    subtotal += product[1] * qty;
    i++;
  }

  const origin = request.headers.get('origin') || new URL(request.url).origin;
  const base = (env.URL || origin).replace(/\/$/, '');
  p.append('mode', 'payment');
  PAYMENT_METHODS.forEach((m, n) => p.append(`payment_method_types[${n}]`, m));
  p.append('payment_method_options[wechat_pay][client]', 'web');
  p.append('locale', 'fr');
  p.append('success_url', base + '/?paiement=ok');
  p.append('cancel_url', base + '/?paiement=annule');
  shippingOptions.forEach((o, n) => {
    const k = `shipping_options[${n}][shipping_rate_data]`;
    p.append(`${k}[type]`, 'fixed_amount');
    p.append(`${k}[display_name]`, o.name);
    p.append(`${k}[fixed_amount][amount]`, String(o.amount));
    p.append(`${k}[fixed_amount][currency]`, 'eur');
    p.append(`${k}[delivery_estimate][minimum][unit]`, 'business_day');
    p.append(`${k}[delivery_estimate][minimum][value]`, String(o.min));
    p.append(`${k}[delivery_estimate][maximum][unit]`, 'business_day');
    p.append(`${k}[delivery_estimate][maximum][value]`, String(o.max));
  });
  p.append('custom_fields[0][key]', 'point_relais');
  p.append('custom_fields[0][label][type]', 'custom');
  p.append('custom_fields[0][label][custom]', 'Point relais / casier (nom ou n°)');
  p.append('custom_fields[0][type]', 'text');
  p.append('custom_fields[0][optional]', 'true');
  p.append('shipping_address_collection[allowed_countries][0]', country);

  try {
    const response = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + key,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: p.toString()
    });
    const data = await response.json();
    if (!response.ok) {
      const stripeMessage = data && data.error && data.error.message;
      const stripeCode = data && data.error && (data.error.code || data.error.type);
      console.error('[create-checkout] Stripe a refusé la session:', response.status, stripeCode || 'sans code', stripeMessage || 'sans message');
      return json(502, { error: stripeMessage || 'Stripe a refusé la création du paiement. Vérifiez la clé et le compte Stripe.' });
    }
    if (!data.url) {
      console.error('[create-checkout] Stripe a répondu sans URL de paiement');
      return json(502, { error: 'Stripe n’a pas renvoyé de lien de paiement.' });
    }
    return json(200, { url: data.url });
  } catch (err) {
    console.error('[create-checkout] Erreur réseau vers Stripe:', err && err.message ? err.message : 'erreur inconnue');
    return json(502, { error: 'Le serveur n’arrive pas à contacter Stripe. Réessayez dans quelques instants.' });
  }
};
