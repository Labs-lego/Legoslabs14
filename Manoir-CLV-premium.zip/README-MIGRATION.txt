MANOIR C. VAUTIER — Cloudflare Pages migration package

STATIC SITE
This folder contains the existing site assets and pages. The checkout endpoint in index.html has been changed to /api/create-checkout.

DEPLOY
1. Create a Cloudflare Pages project and upload/connect this folder as the project root.
2. Set the environment variable STRIPE_SECRET_KEY in Pages settings (use the existing Stripe secret key; do not put it in files).
3. Deploy. Test the site and checkout using Stripe test mode before changing the live domain DNS.
4. Connect manoirclv.fr only after the new deployment is confirmed.

IMPORTANT
Payment function migrated to Cloudflare Pages Functions. Verify Stripe settings and live/test keys, shipping choices, success/cancel URLs, and legal pages before going live.
